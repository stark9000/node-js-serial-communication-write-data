
const serialPortLIB = require('serialport');
var SerialPort = serialPortLIB.SerialPort;
var portNumber = "";
var port = "";

var itemList = [];
// list all serial ports available    
(async () => {
    try {
        const serialPortList = await SerialPort.list();
        if (serialPortList.length > 0) {
            itemList.push("select a port");
            serialPortList.forEach(port => {
                itemList.push(port.path);
            });
        }
    } catch (e) {
        console.log(e);
    }
})();


//server
const content = require('fs').readFileSync(__dirname + '/main.html', 'utf8');

const httpServer = require('http').createServer((req, res) => {
    res.setHeader('Content-Type', 'text/html');
    res.setHeader('Content-Length', Buffer.byteLength(content));
    res.end(content);
});

const io = require('socket.io')(httpServer);

io.on('connect', socket => {
    socket.emit('plist', itemList);

    socket.on('sport', (DATA_RECEIVED_FROM_HTML) => {
        if (DATA_RECEIVED_FROM_HTML == "select a port") {
        } else {
            portNumber = DATA_RECEIVED_FROM_HTML;
        }
    });

    socket.on('sconnect', (DATA_RECEIVED_FROM_HTML) => {
        port = new SerialPort({
            path: portNumber,
            baudRate: 9600
        });

        port.on('open', function () {
            socket.emit('events', 'Serial Port ' + portNumber + ' is opened.');
        });
    });

    socket.on('sdisconnect', (DATA_RECEIVED_FROM_HTML) => {
        port.close(function (err) {
            socket.emit('events', 'Serial Port ' + portNumber + ' is closed.');
        });
    });

    socket.on('son', (DATA_RECEIVED_FROM_HTML) => {
        socket.emit('events', 'On');
        port.write("1");
    });

    socket.on('soff', (DATA_RECEIVED_FROM_HTML) => {
        socket.emit('events', 'Off');
        port.write("0");
    });

});


httpServer.listen(3000, () => {
    console.log('go to http://localhost:3000');
})